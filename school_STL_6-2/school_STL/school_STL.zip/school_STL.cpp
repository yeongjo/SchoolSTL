﻿#include <iostream>
#include <random>
#include <fstream>
#include <string>
#include <vector>
#include <string_view>
#include <set>

using namespace std;

random_device rd;		// 가능하다면 하드웨어 값으로 부터 랜덤 시드를 스스로 생성해서 매번 구동할때마다 예측할수 없는 랜덤값?
default_random_engine dre;
uniform_int_distribution<int> uidAge{ 0, 15 };		// int가 디폴트값이라 빼먹어도 되긴하데 {}로 숫자 제한둘수있다.
uniform_int_distribution<int> uidName{ 'a', 'z' };

class Dog {
	string name;		// 15글자 기본할당됨
	int age;

public:
	Dog() {
		for (int i = 0; i < 10; ++i)
			name += uidName(dre);
		age = uidAge(dre);
	}
	void show() const {
		cout << name << " - " << age << endl;
	}
	string getName() const {		//스트링이 무겁기때문에 스트링포인터만 전달해준다
		return name;
	}
};


template<>
struct less<Dog> {
	bool operator()(const Dog& a, const Dog&b) const {
		return a.getName() < b.getName();
	}
};




//개천마리의 정보를 읽어서 화면에 출력하자

int main()
{
	cout << sizeof(Dog) << endl;
	Dog dogs[1000];

	ofstream out("개천마리", ios::binary);
	out.write((char*)dogs, 1000 * sizeof(Dog));
	out.close();


	ifstream in("개천마리", ios::binary);
	{
		vector<Dog> v;
		v.resize(2000);
		in.read((char*)v.data(), sizeof(Dog) * 1000);
		/*set<Dog> v;

		for (int i = 0; i < 1000; i++) {
			Dog dog;
			in.read((char*)&dog, sizeof(Dog));
			v.insert(dog);
		}*/

		for (const Dog& dog : v)
			dog.show();
	}

	in.close();
} // < -------------- 여기가 끝나면 set<Dog> v 안에 있는 Dog들이 해제되면서 
//오류가 납니다
